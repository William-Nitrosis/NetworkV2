//#include "StandAlonePrivatePCH.h"
#include "AdvancedSessions.h"

void AdvancedSessions::StartupModule()
{
}
 
void AdvancedSessions::ShutdownModule()
{
}
 
IMPLEMENT_MODULE(AdvancedSessions, AdvancedSessions)